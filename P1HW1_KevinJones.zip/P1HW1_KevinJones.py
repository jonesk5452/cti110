# This program demos how the the range
# function can be used with a for loop

def main():
    # print a message five times
    for x in range (5):
        print('Hello World!')
        
# Call the main function.
main()
